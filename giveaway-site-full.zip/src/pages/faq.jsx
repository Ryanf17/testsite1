import React from 'react';
export default function FAQ() {
  return <div><h1>FAQ</h1><p>Q: What time is check-in?<br/>A: 3PM</p></div>;
}
