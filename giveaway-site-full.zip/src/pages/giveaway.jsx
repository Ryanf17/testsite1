import React from 'react';
export default function Giveaway() {
  return <div><h1>Giveaway</h1><p>Access code required to enter.</p></div>;
}
