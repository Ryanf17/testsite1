import React from 'react';
export default function HouseRules() {
  return <div><h1>House Rules</h1><ul><li>No outside alcohol</li><li>Quiet hours: 10PM – 7AM</li><li>Clean up after yourself</li></ul></div>;
}
