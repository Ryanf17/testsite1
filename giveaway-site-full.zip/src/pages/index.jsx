import React from 'react';
export default function Home() {
  return <div><h1>Welcome to Ryan's Giveaways!</h1><p>Join the latest giveaways, check the bar, and more.</p></div>;
}
